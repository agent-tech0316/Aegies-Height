"""UDP transport — generic JSON-over-UDP with timeouts and retry.

Used by D1 Platform to implement the reverse-engineered dog_task protocol,
and by any other platform that needs fire-and-forget or request/response UDP.

This layer has NO knowledge of cmd codes, lab_mode, or any D1-specific semantics.
Those live in platforms/d1.py.
"""
from __future__ import annotations

import asyncio
import json
import logging
import socket
from typing import Any

from ff_sdk.core.exceptions import TimeoutError, TransportError
from ff_sdk.transport.base import Transport, TransportState

log = logging.getLogger(__name__)


class UdpTransport(Transport):
    """Async UDP client.

    Example:
        tx = UdpTransport(host="192.168.234.1", port=8081)
        await tx.open()
        await tx.send_json({"cmd": 122, "type": "cmd"})
        await tx.close()
    """

    name = "udp"

    def __init__(self, host: str, port: int, *, timeout: float = 1.0,
                 bind: tuple[str, int] | None = None) -> None:
        super().__init__()
        self.host = host
        self.port = port
        self.timeout = timeout
        self._bind = bind
        self._transport: asyncio.DatagramTransport | None = None
        self._protocol: _UdpProtocol | None = None

    async def open(self) -> None:
        if self._state is TransportState.OPEN:
            return
        self._state = TransportState.OPENING
        loop = asyncio.get_running_loop()
        try:
            transport, protocol = await loop.create_datagram_endpoint(
                lambda: _UdpProtocol(),
                local_addr=self._bind,
                family=socket.AF_INET,
            )
        except OSError as e:
            self._state = TransportState.ERROR
            raise TransportError(f"UDP open failed: {e}") from e
        self._transport = transport
        self._protocol = protocol
        self._state = TransportState.OPEN
        log.debug("UDP open %s:%d", self.host, self.port)

    async def close(self) -> None:
        if self._transport:
            self._transport.close()
        self._transport = None
        self._protocol = None
        self._state = TransportState.CLOSED

    async def is_alive(self) -> bool:
        return self._state is TransportState.OPEN

    async def send_bytes(self, data: bytes) -> None:
        if self._transport is None or self._state is not TransportState.OPEN:
            raise TransportError("UDP transport not open")
        try:
            self._transport.sendto(data, (self.host, self.port))
        except OSError as e:
            raise TransportError(f"UDP sendto failed: {e}") from e

    async def send_json(self, payload: dict[str, Any]) -> None:
        """Fire-and-forget JSON send."""
        await self.send_bytes(json.dumps(payload, separators=(",", ":")).encode("utf-8"))

    async def request_json(self, payload: dict[str, Any],
                           *, timeout: float | None = None) -> dict[str, Any]:
        """Send JSON and wait for a response. First datagram back wins.

        Note: only safe when the peer responds 1:1; this transport is shared
        per target, so concurrent request_json calls to the same peer may
        race. Higher layers should serialize as needed.
        """
        if self._protocol is None:
            raise TransportError("UDP transport not open")
        deadline = timeout if timeout is not None else self.timeout
        await self.send_json(payload)
        try:
            data = await asyncio.wait_for(self._protocol.next_datagram(), timeout=deadline)
        except asyncio.TimeoutError as e:
            raise TimeoutError(f"UDP request timeout after {deadline}s") from e
        try:
            return json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            raise TransportError(f"UDP response not JSON: {data!r}") from e


class _UdpProtocol(asyncio.DatagramProtocol):
    def __init__(self) -> None:
        self._queue: asyncio.Queue[bytes] = asyncio.Queue()

    def datagram_received(self, data: bytes, addr: tuple[str, int]) -> None:
        self._queue.put_nowait(data)

    def error_received(self, exc: Exception) -> None:
        log.warning("UDP protocol error: %s", exc)

    async def next_datagram(self) -> bytes:
        return await self._queue.get()
