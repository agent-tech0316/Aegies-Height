"""Vesta cloud backend configuration — resolved from the environment.

The cloud host and the application id are platform-identifying, so they are
NEVER hardcoded in source (public naming veil). Operators export them at
runtime:

    export FF_SDK_VESTA_BASE=https://<cloud-host>
    export FF_SDK_VESTA_APPID=<app-id>

`device_type_id` is a numeric model selector required in the control headers
(the cloud rejects interaction commands without it); it is a protocol
constant, not a brand string.
"""
from __future__ import annotations

import os

ENV_BASE = "FF_SDK_VESTA_BASE"
ENV_APPID = "FF_SDK_VESTA_APPID"
ENV_TYPE_ID = "FF_SDK_VESTA_TYPE_ID"

# Numeric device-type id sent in the Device-Type-Id control header. Protocol
# constant (model selector). Override per model via FF_SDK_VESTA_TYPE_ID.
DEFAULT_TYPE_ID = "2"


def base_url() -> str:
    """Cloud base URL from env, trailing slash stripped. Empty if unset."""
    return (os.environ.get(ENV_BASE) or "").rstrip("/")


def app_id() -> str:
    """Application id sent in the X-App-Id header. Empty if unset."""
    return os.environ.get(ENV_APPID) or ""


def device_type_id() -> str:
    """Device-Type-Id control-header value (protocol constant)."""
    return os.environ.get(ENV_TYPE_ID) or DEFAULT_TYPE_ID
