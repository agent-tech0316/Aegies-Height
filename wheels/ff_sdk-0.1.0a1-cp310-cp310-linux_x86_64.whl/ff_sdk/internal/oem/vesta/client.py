"""Vesta native cloud transport — pure REST client (stdlib urllib only).

Hides the cloud control protocol behind ff_sdk-internal types. The flow is:

    send_sms_code → login(sms) → (Token + User-Id headers)
    → device list / bind → /device/interaction/cmd (relayed to the robot)

Adapter callers import ONLY from `ff_sdk.platforms.vesta`, never from this
module directly — that is the vendor-leakage rule (PLAN.md §4.2).

CLOUD RELAY SEMANTICS: control commands POST to the vendor cloud, which
forwards them to the robot. When the robot is offline the cloud answers
`data.current_status == "offline"` and the command is NOT executed. Callers
must treat that as a SOFT failure (no exception) — see `parse_cmd_response`.

The base host / app id are resolved from the environment (config.py); no
platform-identifying constant is baked into source.

Protocol reverse-engineered and real-machine verified; the full contract is
kept in the internal protocol notes (not shipped in source).
"""
from __future__ import annotations

import json
import logging
import urllib.error
import urllib.request
from dataclasses import dataclass, field

from ff_sdk.internal.oem.vesta import endpoints

log = logging.getLogger(__name__)


# ── exceptions (ff_sdk internal; adapter translates to public hierarchy) ──

class VestaSdkUnavailable(RuntimeError):
    """Cloud endpoint unreachable or returned a transport-level error."""


class VestaAuthError(RuntimeError):
    """Login failed, or a request was made before authenticating."""


# ── command vocabulary ───────────────────────────────────────────────
# Friendly alias → wire cmd_type. Every wire value is a generic English
# protocol token (does not name the vendor).

CMD_TYPES: dict[str, str] = {
    # mini gesture set
    "nod": "mini_nod",
    "shake": "mini_shake_head",
    "shake_head": "mini_shake_head",
    "handshake": "mini_handshake",
    "salute": "mini_salute",
    "squat": "mini_squat",
    "sway": "mini_sway",
    "cheer": "mini_cheer",
    "scratch": "mini_scratch_head",
    "scratch_head": "mini_scratch_head",
    "smirk": "mini_smirk",
    "hips": "mini_hands_on_hips",
    "hands_on_hips": "mini_hands_on_hips",
    "happy": "mini_happy",
    "turn_left": "mini_turn_left",
    "turn_right": "mini_turn_right",
    # high-level actions
    "standup": "standup",
    "stand": "standup",
    "stand_up": "standup",
    "follow": "follow",
    "charge": "go-charge",
    "go_charge": "go-charge",
    "go-charge": "go-charge",
    "photo": "take_photo",
    "take_photo": "take_photo",
    "record": "record_video",
    "record_video": "record_video",
}

# remote_control movement directions (discrete; the cloud relay only accepts
# these four for the joystick-equivalent command).
DIRECTIONS: tuple[str, ...] = ("forward", "backward", "turn_left", "turn_right")


@dataclass(frozen=True)
class CmdResult:
    """Parsed result of an interaction command."""
    ok: bool
    code: int
    is_conflict: bool
    current_status: str  # "online" | "offline" | ""
    raw: dict = field(default_factory=dict)


def parse_cmd_response(resp: dict) -> CmdResult:
    """Turn a raw /device/interaction/cmd response into a CmdResult.

    Offline / conflict are SOFT failures (ok=False, no exception)."""
    code = int(resp.get("code", 0) or 0)
    data = resp.get("data") or {}
    is_conflict = bool(data.get("is_conflict", False))
    current_status = str(data.get("current_status", "") or "")
    ok = (code == 200) and (current_status != "offline") and (not is_conflict)
    return CmdResult(
        ok=ok, code=code, is_conflict=is_conflict,
        current_status=current_status, raw=resp,
    )


# ── REST client ──────────────────────────────────────────────────────

class VestaCloudClient:
    """Blocking REST client. Async adapters wrap calls in asyncio.to_thread."""

    def __init__(
        self,
        *,
        base_url: str,
        app_id: str = "",
        device_type_id: str = "2",
        timeout: float = 15.0,
    ) -> None:
        self._base = base_url.rstrip("/")
        self._app_id = app_id
        self._type_id = str(device_type_id)
        self._timeout = timeout
        self._token: str | None = None
        self._user_id: str | None = None

    # --- session state ------------------------------------------------

    @property
    def is_authed(self) -> bool:
        return bool(self._token and self._user_id)

    @property
    def user_id(self) -> str | None:
        return self._user_id

    def set_session(self, token: str | None, user_id: str | int | None) -> None:
        self._token = token or None
        self._user_id = str(user_id) if user_id not in (None, "") else None

    # --- plumbing -----------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        body: dict | None = None,
        headers: dict | None = None,
    ) -> dict:
        url = self._base + path
        h: dict[str, str] = {}
        if self._app_id:
            h["X-App-Id"] = self._app_id
        data = None
        if body is not None:
            data = json.dumps(body).encode()
            h["Content-Type"] = "application/json"
        if headers:
            h.update(headers)
        req = urllib.request.Request(url, data=data, headers=h, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as r:
                raw = r.read()
        except urllib.error.HTTPError as e:
            # The API returns JSON error bodies even on non-2xx.
            try:
                return json.loads(e.read().decode(errors="ignore"))
            except Exception as e2:  # noqa: BLE001
                raise VestaSdkUnavailable(
                    f"{method} {path}: HTTP {e.code}"
                ) from e2
        except urllib.error.URLError as e:
            raise VestaSdkUnavailable(f"{method} {path}: {e.reason}") from e
        except Exception as e:  # noqa: BLE001 — translate all transport errors
            raise VestaSdkUnavailable(f"{method} {path}: {e}") from e
        try:
            return json.loads(raw.decode(errors="ignore"))
        except Exception:  # noqa: BLE001
            return {"raw": raw[:500].decode(errors="ignore")}

    def _auth_headers(self) -> dict[str, str]:
        if not self.is_authed:
            raise VestaAuthError(
                "not authenticated — call login() or set_session() first"
            )
        assert self._token is not None and self._user_id is not None
        return {"Token": self._token, "User-Id": self._user_id}

    def _device_headers(self, device_sn: str, device_id: str) -> dict[str, str]:
        h = self._auth_headers()
        h.update({
            "Device-Sn": device_sn,
            "Device-Id": str(device_id or ""),
            "Device-Type-Id": self._type_id,
        })
        return h

    # --- auth ---------------------------------------------------------

    def send_sms_code(self, phone: str, area_code: str = "+86") -> dict:
        return self._request(
            "POST", endpoints.SEND_SMS_CODE,
            body={"phone": phone, "area_code": area_code},
        )

    def login(self, phone: str, sms_code: str, area_code: str = "+86") -> dict:
        r = self._request(
            "POST", endpoints.LOGIN_SMS,
            body={"phone": phone, "area_code": area_code, "sms_code": sms_code},
        )
        data = r.get("data") or {}
        if r.get("code") == 200 and data.get("token"):
            self.set_session(data.get("token"), data.get("user_id"))
            return data
        raise VestaAuthError(
            f"login rejected: code={r.get('code')} "
            f"msg={r.get('msg') or r.get('message') or ''}"
        )

    # --- devices ------------------------------------------------------

    def list_devices(self) -> list[dict]:
        r = self._request("GET", endpoints.DEVICE_LIST, headers=self._auth_headers())
        return list(r.get("data") or [])

    def find_device_id(self, device_sn: str) -> str:
        for d in self.list_devices():
            if d.get("device_sn") == device_sn:
                return str(d.get("device_id", ""))
        return ""

    def bind_robot(self, device_sn: str) -> dict:
        body = {
            "user_id": self._user_id,
            "device_sn": device_sn,
            "token": self._token,
        }
        return self._request(
            "POST", endpoints.BIND_ROBOT, body=body, headers=self._auth_headers(),
        )

    def unbind_robot(self, device_sn: str) -> dict:
        h = self._auth_headers()
        h["Device-Sn"] = device_sn
        return self._request("GET", endpoints.UNBIND_ROBOT, headers=h)

    # --- control / telemetry ------------------------------------------

    def interaction_cmd(
        self,
        device_sn: str,
        device_id: str,
        cmd_type: str,
        status: str = "on",
        data: dict | None = None,
    ) -> dict:
        body: dict = {"cmd_type": cmd_type, "status": status}
        if data is not None:
            body["data"] = data
        return self._request(
            "POST", endpoints.INTERACTION_CMD,
            body=body, headers=self._device_headers(device_sn, device_id),
        )

    def system_status(self, device_sn: str, device_id: str) -> dict:
        return self._request(
            "GET", endpoints.SYSTEM_STATUS,
            headers=self._device_headers(device_sn, device_id),
        )
