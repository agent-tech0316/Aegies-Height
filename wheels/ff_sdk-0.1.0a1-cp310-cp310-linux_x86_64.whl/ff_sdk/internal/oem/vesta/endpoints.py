"""Vesta cloud REST endpoint paths.

Pure path constants — the host is never baked in here (see config.py, it is
resolved from the environment). These are generic REST routes; on their own
they do not identify the underlying vendor.
"""
from __future__ import annotations

# --- account / auth ---------------------------------------------------
SEND_SMS_CODE = "/user/send_sms_code"
LOGIN_SMS = "/user/login/sms"

# --- device management ------------------------------------------------
DEVICE_LIST = "/user/device/list"
BIND_ROBOT = "/user/bind/robot"
UNBIND_ROBOT = "/user/unbind/robot"

# --- control / telemetry ---------------------------------------------
INTERACTION_CMD = "/device/interaction/cmd"
SYSTEM_STATUS = "/device/system/status/v1"
