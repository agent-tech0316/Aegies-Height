"""Vesta (compact companion robot) native cloud transport layer.

Hides the cloud control protocol (SMS login → Token/User-Id headers →
device bind → /device/interaction/cmd relay) behind ff_sdk-internal types.
Adapter callers should import ONLY from `ff_sdk.platforms.vesta`, never from
this module directly — that is the vendor-leakage rule (per PLAN.md §4.2).

The base host / app id are resolved from the environment (config.py); no
platform-identifying constant is baked into source.

Protocol reverse-engineered and real-machine verified; the full contract is
kept in the internal protocol notes (not shipped in source).
"""
from __future__ import annotations

from ff_sdk.internal.oem.vesta import config, endpoints
from ff_sdk.internal.oem.vesta.client import (
    CMD_TYPES,
    DIRECTIONS,
    CmdResult,
    VestaAuthError,
    VestaCloudClient,
    VestaSdkUnavailable,
    parse_cmd_response,
)

__all__ = [
    "config",
    "endpoints",
    "VestaCloudClient",
    "VestaSdkUnavailable",
    "VestaAuthError",
    "CmdResult",
    "parse_cmd_response",
    "CMD_TYPES",
    "DIRECTIONS",
]
