"""OEM-specific implementation details.

This package holds:
    - runtime_rpc/     — runtime HTTP RPC client wrappers (Futurist, Master), Phase 1.5+
    - ros2/            — vendor protocol ros2 bindings, Phase 1.5+
    - dog_task/        — Aegis UDP protocol (we wrote this, no OEM SDK exists)
    - aegis/           — Aegis native (eCAL + mc_sdk) bindings, Phase 2+

**Rule**: nothing under ff_sdk.internal.oem may be imported from outside
ff_sdk.platforms.*. Public API types never reference these modules.
"""
