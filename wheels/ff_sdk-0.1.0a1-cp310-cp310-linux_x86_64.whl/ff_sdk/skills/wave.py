"""ff_sdk.skills.wave — wave hand/paw across all robot platforms.

Each platform uses a different underlying mechanism, but caller writes
one line: `await ff_sdk.skills.wave(session)`.

Implementations:
  - Navi (a100_dev): do_action(20542 = wave_hand) via navi namespace
  - A2:    motion.do_preset("wave") via runtime RPC
  - X2:    motion.do_preset_oem(motion_id=3001, area=11) via app_proxy
  - D1:    motion.do_preset("handshake") fallback (no proper wave)
  - Mujoco: stand pose + 1s pause (visual placeholder for sim)
"""
from __future__ import annotations

import logging

from ff_sdk.core.exceptions import CapabilityNotSupported

log = logging.getLogger(__name__)


__skill_meta__ = {
    "name": "wave",
    "version": "0.1.0",
    "author": "ff_sdk_core",
    "author_pubkey": None,             # Phase 5: ed25519 pubkey
    "signature": None,                  # Phase 5: cosign signature
    "requires_capabilities": ["motion"],
    "requires_platforms": ["a2", "x2", "d1", "navi", "mujoco"],
    "permission": "low_risk",          # low_risk / motion / unrestricted
    "description": "Wave hand/paw greeting across A2/X2/D1/Navi/Mujoco",
}


async def wave(session, *, side: str = "right") -> dict:
    """Wave hand/paw across robots.

    Args:
        session: ff_sdk.Session from `await ff_sdk.connect(...)`
        side: "right" | "left" (most platforms ignore this currently)

    Returns:
        dict {ok: bool, message: str, platform: str}

    Raises:
        CapabilityNotSupported: platform doesn't have a wave equivalent
    """
    platform = session.adapter.platform_name

    if platform == "navi":
        # Navi A100 Dev: do_action(20542 = wave_hand)
        navi = session.adapter.navi
        if navi is None:
            raise CapabilityNotSupported(
                "wave requires session.navi (a100_dev variant)"
            )
        try:
            # 优先 by-name lookup (跟 fw 解耦)
            actions = await navi.list_actions()
            action_id = actions.by_name("wave_hand")
            if action_id is None:
                action_id = 20542  # fallback to known ID
        except Exception:  # noqa: BLE001
            action_id = 20542
        result = await navi.do_action(action_id, hold_time=3.0)
        return {"ok": True, "message": f"navi wave_hand → {result}", "platform": "navi"}

    if platform == "a2":
        # A2 humanoid: motion.do_preset("wave") if available
        if session.motion is None:
            raise CapabilityNotSupported("a2 motion not available")
        result = await session.motion.do_preset("wave")
        return {
            "ok": getattr(result, "success", False),
            "message": f"a2 do_preset(wave) → {result}",
            "platform": "a2",
        }

    if platform == "x2":
        # X2: motion.do_preset_oem(motion_id=3001, area=11) per OEM Go reverse
        if session.motion is None or not hasattr(session.motion, "do_preset_oem"):
            raise CapabilityNotSupported("x2 motion.do_preset_oem not available")
        result = await session.motion.do_preset_oem(motion_id=3001, area=11)
        return {
            "ok": getattr(result, "success", False),
            "message": f"x2 do_preset_oem(3001, 11) → {result}",
            "platform": "x2",
        }

    if platform == "d1":
        # D1 quadruped has no proper wave; degrade to handshake
        if session.motion is None:
            raise CapabilityNotSupported("d1 motion not available")
        try:
            result = await session.motion.do_preset("handshake")
            return {
                "ok": getattr(result, "success", False),
                "message": f"d1 handshake (no wave) → {result}",
                "platform": "d1",
            }
        except CapabilityNotSupported:
            raise CapabilityNotSupported("d1 has no wave-equivalent preset")

    if platform == "mujoco":
        # Sim: stand 1s as a visual placeholder
        if session.motion is None:
            raise CapabilityNotSupported("mujoco motion not available")
        result = await session.motion.stand()
        return {
            "ok": True,
            "message": f"mujoco wave (stand placeholder) → {result}",
            "platform": "mujoco",
        }

    raise CapabilityNotSupported(f"wave not implemented for platform={platform!r}")
