"""VestaAdapter — Vesta compact companion robot (FF product line).

Vesta is controlled entirely through a vendor cloud REST relay (no LAN /
ROS path): the client authenticates by SMS login, the cloud hands back a
``Token`` + ``User-Id`` pair, and control commands POST to the cloud which
forwards them to the robot.

URI form:
    VS-<sn>            → Vesta, default model
    VESTA              → Vesta, model resolved from config (no explicit sn)
    Config.extra["vesta_variant"] = "default"     explicit override

Cloud host / app id (platform-identifying) are resolved from the environment
— they are NEVER hardcoded in source (public naming veil):
    FF_SDK_VESTA_BASE   = https://<cloud-host>
    FF_SDK_VESTA_APPID  = <app-id>
    FF_SDK_VESTA_TYPE_ID= <numeric model selector, protocol constant; default 2>

Credentials (any one path):
    FF_SDK_VESTA_TOKEN + FF_SDK_VESTA_USER_ID      pre-obtained session
    FF_SDK_VESTA_PHONE + FF_SDK_VESTA_SMS_CODE     SMS login at connect()
    Config.extra["vesta_token"] / ["vesta_user_id"] / ["vesta_phone"] / …
  …or call ``session.adapter.vesta.login(phone, sms_code)`` after connect.

CLOUD RELAY SEMANTICS: when the robot is offline the cloud accepts the HTTP
request (code 200) but reports ``current_status="offline"`` and does NOT run
the command. The adapter surfaces that as a SOFT failure — ``MotionResult``
with ``success=False`` — never a raised exception. A second controller takes
``is_conflict=True`` (also a soft failure).

Capabilities:
    motion  — cmd_vel (discrete direction relay) / stop / stand / damping /
              do_preset (the gesture + action vocabulary)
    state   — battery (best-effort from system status) / status / pose(❌)
    session.adapter.vesta — full vendor menu (login, device mgmt, the gesture
              catalog, action_perform, raw status).

Protocol was reverse-engineered and real-machine verified; the full contract
is kept in the internal protocol notes (not shipped in source).
"""
from __future__ import annotations

import asyncio
import logging
import os
from typing import TYPE_CHECKING

from ff_sdk.capabilities.motion import MotionCapability
from ff_sdk.capabilities.state import StateCapability
from ff_sdk.capabilities.types import (
    BatteryState,
    MotionResult,
    Pose,
    RobotStatus,
)
from ff_sdk.core.exceptions import (
    AuthenticationError,
    CapabilityNotSupported,
    ConfigError,
)
from ff_sdk.core.exceptions import ConnectionError as FFConnectionError
from ff_sdk.internal.oem.vesta import (
    CMD_TYPES,
    DIRECTIONS,
    CmdResult,
    VestaAuthError,
    VestaCloudClient,
    VestaSdkUnavailable,
    config as vesta_config,
    parse_cmd_response,
)
from ff_sdk.platforms.base import (
    DiagnosticCheck,
    DiagnosticReport,
    HealthStatus,
    PlatformAdapter,
)

if TYPE_CHECKING:
    pass

log = logging.getLogger(__name__)

_URI_PREFIX = "VS-"

VARIANT_DEFAULT = "default"
_VALID_VARIANTS = (VARIANT_DEFAULT,)


def _parse_variant(target: str, override: str | None) -> str:
    """URI / config → variant id. One model today (forward-compat shape)."""
    if override:
        v = override.lower().strip()
        if v not in _VALID_VARIANTS:
            raise ConfigError(
                f"vesta_variant must be one of {_VALID_VARIANTS!r}, got {override!r}"
            )
        return v
    return VARIANT_DEFAULT


def _parse_sn(target: str) -> str:
    """Extract the device serial from a 'VS-<sn>' target. '' for bare 'VESTA'."""
    t = target.strip()
    if t[:3].upper() == _URI_PREFIX:
        return t[3:]
    return ""


def _vel_to_direction(linear: float, angular: float, *, eps: float = 1e-3) -> str | None:
    """Map a continuous (vx, wz) command to the cloud's discrete direction.

    The relay only accepts forward/backward/turn_left/turn_right. Linear motion
    wins ties; returns None at rest (→ caller issues stop). ROS yaw convention:
    angular > 0 = CCW = turn_left.
    """
    if abs(linear) < eps and abs(angular) < eps:
        return None
    if abs(linear) >= abs(angular):
        return "forward" if linear > 0 else "backward"
    return "turn_left" if angular > 0 else "turn_right"


def _cmd_result_to_motion(cmd_type: str, r: CmdResult) -> MotionResult:
    """CmdResult → MotionResult. Offline / conflict are soft failures."""
    if r.current_status == "offline":
        return MotionResult(
            False,
            f"{cmd_type}: robot offline — cloud command was not delivered",
            details={"cmd_type": cmd_type, "current_status": "offline"},
        )
    if r.is_conflict:
        return MotionResult(
            False,
            f"{cmd_type}: control conflict — another session is in control",
            details={"cmd_type": cmd_type, "is_conflict": "true"},
        )
    if not r.ok:
        return MotionResult(
            False,
            f"{cmd_type}: cloud returned code={r.code}",
            details={"cmd_type": cmd_type, "code": str(r.code)},
        )
    return MotionResult(
        True,
        f"{cmd_type} ok",
        details={"cmd_type": cmd_type, "current_status": r.current_status or "online"},
    )


class VestaAdapter(PlatformAdapter):
    platform_name = "vesta"

    def __init__(self, **kwargs: object) -> None:
        super().__init__(**kwargs)  # type: ignore[arg-type]
        self._target: str = ""
        self._variant: str = VARIANT_DEFAULT
        self._base: str = ""
        self._app_id: str = ""
        self._type_id: str = "2"
        self._device_sn: str = ""
        self._device_id: str = ""
        self._dry_run: bool = bool(self.config.dry_run) or bool(
            os.environ.get("FF_SDK_DRY_RUN")
        )
        self._client: VestaCloudClient | None = None
        self._connected: bool = False
        self._motion: "MotionCapability | None" = None
        self._state: "StateCapability | None" = None
        self._vesta_ns: "_VestaExtensions | None" = None

    # --- Lifecycle ---------------------------------------------------

    async def connect(self, target: str) -> None:
        self._target = target.strip()
        upper = self._target.upper()
        if not (upper.startswith(_URI_PREFIX) or upper == "VESTA"):
            raise ConfigError(
                f"vesta adapter expects 'VS-<sn>' or 'VESTA', got {target!r}"
            )

        self._variant = _parse_variant(
            self._target, self.config.extra.get("vesta_variant")
        )
        self._device_sn = (
            self.config.extra.get("vesta_device_sn") or _parse_sn(self._target)
        )
        self._base = self.config.extra.get("vesta_base") or vesta_config.base_url()
        self._app_id = self.config.extra.get("vesta_appid") or vesta_config.app_id()
        self._type_id = str(
            self.config.extra.get("vesta_type_id") or vesta_config.device_type_id()
        )

        log.info(
            "[vesta] connecting %s (variant=%s, dry_run=%s)",
            self._target, self._variant, self._dry_run,
        )

        if self._dry_run:
            self._client = None
            self._connected = True
            self._instantiate_caps()
            return

        if not self._base:
            raise ConfigError(
                "vesta cloud base URL not set — export FF_SDK_VESTA_BASE="
                "https://<host> (kept out of source per the naming veil), "
                "or set FF_SDK_DRY_RUN=1 for a stub."
            )

        self._client = VestaCloudClient(
            base_url=self._base,
            app_id=self._app_id,
            device_type_id=self._type_id,
            timeout=max(15.0, self.config.transport_timeout * 3),
        )

        # Auth: a pre-obtained token needs no network; phone+sms_code logs in.
        token = self.config.extra.get("vesta_token") or os.environ.get(
            "FF_SDK_VESTA_TOKEN"
        )
        user_id = self.config.extra.get("vesta_user_id") or os.environ.get(
            "FF_SDK_VESTA_USER_ID"
        )
        phone = self.config.extra.get("vesta_phone") or os.environ.get(
            "FF_SDK_VESTA_PHONE"
        )
        sms_code = self.config.extra.get("vesta_sms_code") or os.environ.get(
            "FF_SDK_VESTA_SMS_CODE"
        )
        area_code = (
            self.config.extra.get("vesta_area_code")
            or os.environ.get("FF_SDK_VESTA_AREA_CODE")
            or "+86"
        )

        if token:
            self._client.set_session(token, user_id)
        elif phone and sms_code:
            try:
                await asyncio.to_thread(
                    self._client.login, phone, sms_code, area_code
                )
            except VestaAuthError as e:
                raise AuthenticationError(f"vesta login failed: {e}") from e
            except VestaSdkUnavailable as e:
                raise FFConnectionError(
                    f"vesta cloud unreachable at {self._base}: {e}"
                ) from e
        else:
            log.warning(
                "[vesta] connected without credentials — call "
                "session.adapter.vesta.login(phone, sms_code) before control"
            )

        # Resolve the device_id for the target SN if we can (control needs it).
        if self._client.is_authed and self._device_sn and not self._device_id:
            try:
                self._device_id = await asyncio.to_thread(
                    self._client.find_device_id, self._device_sn
                )
            except VestaSdkUnavailable as e:
                raise FFConnectionError(
                    f"vesta device list unreachable at {self._base}: {e}"
                ) from e

        self._connected = True
        self._instantiate_caps()

    def _instantiate_caps(self) -> None:
        self._motion = _VestaMotion(self)
        self._state = _VestaState(self)
        self._vesta_ns = _VestaExtensions(self)

    async def disconnect(self) -> None:
        self._client = None
        self._motion = None
        self._state = None
        self._vesta_ns = None
        self._connected = False
        self._device_id = ""

    # --- Capability advertisement -----------------------------------

    def capabilities(self) -> set[str]:
        return {"motion", "state"}

    # --- Capability accessors ---------------------------------------

    @property
    def motion(self) -> "MotionCapability | None":
        return self._motion

    @property
    def state(self) -> "StateCapability | None":
        return self._state

    @property
    def vesta(self) -> "_VestaExtensions | None":
        """Platform-specific namespace for Vesta-only cloud features.

        Exposes login / device management, the full gesture + action catalog
        (nod / salute / follow / go-charge / take_photo / record_video / …),
        action_perform by id, and the raw system status. Accessed via
        ``session.adapter.vesta``. NOT cross-platform — for portable code use
        ``session.motion`` / ``session.state`` or ``ff_sdk.skills.*``.
        """
        return self._vesta_ns

    @property
    def variant(self) -> str:
        return self._variant

    # --- Shared control helpers (used by motion + state + namespace) ----

    @staticmethod
    def _resolve_wire(name: str) -> str:
        """Friendly alias → wire cmd_type (pass-through if already a wire token)."""
        return CMD_TYPES.get(name.lower().strip(), name)

    async def _ensure_device(self) -> None:
        """Lazily resolve the active device_id from the SN if not cached."""
        if self._device_id or self._client is None or not self._device_sn:
            return
        if not self._client.is_authed:
            return
        self._device_id = await asyncio.to_thread(
            self._client.find_device_id, self._device_sn
        )

    async def _send_cmd(
        self,
        cmd_type: str,
        status: str = "on",
        data: dict | None = None,
    ) -> MotionResult:
        """POST an interaction command (cmd_type already a wire token) and
        translate the cloud response into a MotionResult."""
        if self._dry_run:
            return MotionResult(
                True, "dry-run",
                details={"cmd_type": cmd_type, "status": str(status)},
            )
        if self._client is None:
            raise FFConnectionError("vesta adapter not connected")
        if not self._device_sn:
            return MotionResult(
                False, "no active device — call select_device(sn) first"
            )
        await self._ensure_device()
        try:
            resp = await asyncio.to_thread(
                self._client.interaction_cmd,
                self._device_sn, self._device_id, cmd_type, status, data,
            )
        except VestaAuthError as e:
            raise AuthenticationError(f"vesta not authenticated: {e}") from e
        except VestaSdkUnavailable as e:
            return MotionResult(False, f"{cmd_type}: cloud unreachable: {e}")
        return _cmd_result_to_motion(cmd_type, parse_cmd_response(resp))

    def _ns(self) -> "_VestaExtensions":
        if self._vesta_ns is None:
            raise FFConnectionError("vesta adapter not connected")
        return self._vesta_ns

    # --- High-level convenience (delegate to the namespace) ------------
    # Direct, ergonomic surface mirroring the vendor app. The full menu lives
    # on `self.vesta`; these are the most-used shortcuts.

    async def login(self, phone: str, sms_code: str, area_code: str = "+86") -> dict:
        return await self._ns().login(phone, sms_code, area_code)

    async def list_devices(self) -> list[dict]:
        return await self._ns().list_devices()

    async def select_device(self, device_sn: str) -> str:
        return await self._ns().select_device(device_sn)

    async def move(self, direction: str) -> MotionResult:
        return await self._ns().move(direction)

    async def stop(self) -> MotionResult:
        return await self._ns().stop()

    async def action(
        self, cmd_type: str, status: str = "on", data: dict | None = None
    ) -> MotionResult:
        return await self._ns().action(cmd_type, status, data)

    async def get_state(self) -> dict:
        return await self._ns().get_status()

    async def nod(self) -> MotionResult:
        return await self._ns().nod()

    async def standup(self) -> MotionResult:
        return await self._ns().standup()

    async def follow(self) -> MotionResult:
        return await self._ns().follow()

    async def charge(self) -> MotionResult:
        return await self._ns().charge()

    # --- Diagnostics -------------------------------------------------

    def diagnose(self) -> DiagnosticReport:
        checks: list[DiagnosticCheck] = []

        if self._dry_run:
            checks.append(DiagnosticCheck(
                name="cloud dry-run", status=HealthStatus.OK,
                detail=f"FF_SDK_DRY_RUN=1 (variant={self._variant})",
            ))
            overall = HealthStatus.OK
        elif self._connected and self._client is not None:
            authed = self._client.is_authed
            checks.append(DiagnosticCheck(
                name="cloud session", status=HealthStatus.OK if authed else HealthStatus.WARN,
                detail=("authenticated" if authed
                        else "connected but NOT authenticated — call "
                             "session.adapter.vesta.login(phone, sms_code)"),
            ))
            checks.append(DiagnosticCheck(
                name="active device",
                status=HealthStatus.OK if self._device_id else HealthStatus.WARN,
                detail=(f"sn={self._device_sn} id={self._device_id}"
                        if self._device_id
                        else f"sn={self._device_sn or 'unset'} — id unresolved "
                             "(call select_device)"),
            ))
            overall = HealthStatus.OK if authed else HealthStatus.WARN
        else:
            checks.append(DiagnosticCheck(
                name="cloud session", status=HealthStatus.FAIL,
                detail="not connected",
            ))
            overall = HealthStatus.FAIL

        if not self._dry_run and not self._base:
            checks.append(DiagnosticCheck(
                name="config", status=HealthStatus.FAIL,
                detail="FF_SDK_VESTA_BASE not set",
            ))
            overall = HealthStatus.FAIL

        return DiagnosticReport(
            platform=self.platform_name,
            target=self._target or "unset",
            overall=overall,
            checks=tuple(checks),
            extra={
                "base": self._base or "(unset)",
                "app_id_set": str(bool(self._app_id)),
                "device_sn": self._device_sn or "(unset)",
                "device_type_id": self._type_id,
                "variant": self._variant,
                "transport": "cloud_rest",
                "dry_run": str(self._dry_run),
            },
        )

    # --- Emergency stop ----------------------------------------------

    async def e_stop(self, *, reason: str = "manual") -> None:
        """Best-effort idempotent halt over the cloud relay.

        There is no zero-torque hardware e-stop over the cloud API, so the
        safest cloud-side action is to cancel locomotion (remote_control off).
        Must not raise — errors are swallowed and logged.
        """
        log.warning("[vesta] e_stop (reason=%s)", reason)
        if self._dry_run or self._client is None or not self._client.is_authed:
            return
        if not self._device_sn:
            return
        try:
            await self._ensure_device()
            await asyncio.to_thread(
                self._client.interaction_cmd,
                self._device_sn, self._device_id, "remote_control", "off", None,
            )
        except Exception as e:  # noqa: BLE001 — e_stop must be best-effort
            log.error("[vesta] e_stop failed: %s", e)


# ═══════════════════════════════════════════════════════════════════
# Capability implementations
# ═══════════════════════════════════════════════════════════════════


class _VestaMotion(MotionCapability):
    """Vesta motion over the cloud relay.

    cmd_vel maps a continuous (vx, wz) to the cloud's discrete joystick
    direction (the relay does not accept continuous velocities). For full
    fidelity gestures use do_preset / session.adapter.vesta.*.
    """

    def __init__(self, adapter: "VestaAdapter") -> None:
        super().__init__(adapter)
        self._vesta: VestaAdapter = adapter

    async def cmd_vel(
        self,
        linear: float = 0.0,
        angular: float = 0.0,
        lateral: float = 0.0,
    ) -> MotionResult:
        direction = _vel_to_direction(linear, angular)
        if direction is None:
            return await self.stop()
        return await self._vesta._send_cmd(
            "remote_control", "on", {"type": "1", "direction": direction}
        )

    async def stop(self) -> MotionResult:
        return await self._vesta._send_cmd("remote_control", "off", None)

    async def stand(self) -> MotionResult:
        return await self._vesta._send_cmd("standup", "on", None)

    async def damping(self) -> MotionResult:
        """No zero-torque damping over the cloud relay; cancel locomotion."""
        return await self.stop()

    async def do_preset(self, name: str) -> MotionResult:
        key = name.lower().strip()
        if key not in CMD_TYPES:
            raise CapabilityNotSupported(
                f"vesta presets {sorted(set(CMD_TYPES))}; got {name!r}. "
                f"Use session.adapter.vesta.perform(action_id) for the "
                f"action_perform menu."
            )
        return await self._vesta._send_cmd(CMD_TYPES[key], "on", None)


class _VestaState(StateCapability):
    """Vesta telemetry from /device/system/status/v1 (best-effort parse).

    The status payload schema is vendor-defined; battery / mode fields are
    located heuristically. When a recognizable battery field is absent we
    raise CapabilityNotSupported rather than fabricate a value.
    """

    _BATTERY_KEYS = (
        "battery", "battery_level", "battery_percent", "batteryPercent",
        "power", "soc", "electricity", "battery_capacity",
    )
    _CHARGING_KEYS = ("is_charging", "charging", "charge_status", "chargeStatus")
    _STATE_KEYS = ("state", "robot_state", "mode", "status", "fsm_state", "work_status")
    _STATE_MAP = {
        "standing": RobotStatus.STANDING, "stand": RobotStatus.STANDING,
        "moving": RobotStatus.MOVING, "walk": RobotStatus.MOVING,
        "walking": RobotStatus.MOVING, "running": RobotStatus.MOVING,
        "lying": RobotStatus.LYING, "lie": RobotStatus.LYING, "prone": RobotStatus.LYING,
        "charging": RobotStatus.CHARGING, "charge": RobotStatus.CHARGING,
        "idle": RobotStatus.IDLE, "rest": RobotStatus.IDLE,
        "fault": RobotStatus.FAULT, "error": RobotStatus.FAULT,
        "estop": RobotStatus.ESTOPPED, "e_stop": RobotStatus.ESTOPPED,
        "ota": RobotStatus.OTA,
    }

    def __init__(self, adapter: "VestaAdapter") -> None:
        super().__init__(adapter)
        self._vesta: VestaAdapter = adapter

    async def _status_data(self) -> dict:
        if self._vesta._client is None:
            raise FFConnectionError("vesta adapter not connected")
        await self._vesta._ensure_device()
        try:
            resp = await asyncio.to_thread(
                self._vesta._client.system_status,
                self._vesta._device_sn, self._vesta._device_id,
            )
        except VestaAuthError as e:
            raise AuthenticationError(f"vesta not authenticated: {e}") from e
        except VestaSdkUnavailable as e:
            raise FFConnectionError(f"vesta system status unreachable: {e}") from e
        return resp.get("data") or {}

    @classmethod
    def _find_battery_percent(cls, data: dict) -> float | None:
        for k in cls._BATTERY_KEYS:
            v = data.get(k)
            if isinstance(v, bool):
                continue
            if isinstance(v, (int, float)):
                pct = float(v)
                if pct > 1.0:
                    pct = pct / 100.0
                return max(0.0, min(1.0, pct))
        for sub in ("status", "system", "device", "battery_info"):
            if isinstance(data.get(sub), dict):
                r = cls._find_battery_percent(data[sub])
                if r is not None:
                    return r
        return None

    @classmethod
    def _find_charging(cls, data: dict) -> bool:
        for k in cls._CHARGING_KEYS:
            v = data.get(k)
            if isinstance(v, bool):
                return v
            if isinstance(v, (int, float)):
                return bool(v)
            if isinstance(v, str):
                return v.strip().lower() in ("1", "true", "charging", "yes")
        return False

    async def battery(self) -> BatteryState:
        if self._vesta._dry_run:
            return BatteryState(percent=0.9, voltage=None, is_charging=False)
        data = await self._status_data()
        pct = self._find_battery_percent(data)
        if pct is None:
            raise CapabilityNotSupported(
                "vesta system status carried no recognizable battery field; "
                "inspect the raw payload via session.adapter.vesta.get_status()"
            )
        return BatteryState(percent=pct, is_charging=self._find_charging(data))

    async def status(self) -> RobotStatus:
        if self._vesta._dry_run:
            return RobotStatus.IDLE
        data = await self._status_data()
        for k in self._STATE_KEYS:
            v = data.get(k)
            if isinstance(v, str) and v.strip().lower() in self._STATE_MAP:
                return self._STATE_MAP[v.strip().lower()]
        cur = str(data.get("current_status", "") or "").lower()
        if cur == "online":
            return RobotStatus.IDLE
        return RobotStatus.UNKNOWN

    async def pose(self) -> Pose:
        raise CapabilityNotSupported(
            "vesta cloud API does not expose odometry pose"
        )


# ═══════════════════════════════════════════════════════════════════
# Vesta platform-specific namespace (session.adapter.vesta)
# ═══════════════════════════════════════════════════════════════════


class _VestaExtensions:
    """Vesta-only cloud features. Accessed via ``session.adapter.vesta``.

    NOT cross-platform — calling these against another robot will fail. For
    portable code use ``ff_sdk.skills.*`` or the standard motion/state caps.
    """

    def __init__(self, adapter: "VestaAdapter") -> None:
        self._vesta: VestaAdapter = adapter

    @property
    def _client(self) -> VestaCloudClient:
        c = self._vesta._client
        if c is None:
            raise FFConnectionError("vesta adapter not connected")
        return c

    # ── account / auth ──────────────────────────────────────────────

    async def send_sms_code(self, phone: str, area_code: str = "+86") -> dict:
        if self._vesta._dry_run:
            return {"code": 200, "dry_run": True}
        return await asyncio.to_thread(self._client.send_sms_code, phone, area_code)

    async def login(self, phone: str, sms_code: str, area_code: str = "+86") -> dict:
        if self._vesta._dry_run:
            return {"code": 200, "dry_run": True}
        try:
            return await asyncio.to_thread(
                self._client.login, phone, sms_code, area_code
            )
        except VestaAuthError as e:
            raise AuthenticationError(f"vesta login failed: {e}") from e
        except VestaSdkUnavailable as e:
            raise FFConnectionError(f"vesta cloud unreachable: {e}") from e

    # ── device management ───────────────────────────────────────────

    async def list_devices(self) -> list[dict]:
        if self._vesta._dry_run:
            return [{
                "device_sn": self._vesta._device_sn or "VS-DRY",
                "device_name": "vesta-dry-run",
                "device_id": "0",
            }]
        return await asyncio.to_thread(self._client.list_devices)

    async def select_device(self, device_sn: str) -> str:
        """Set the active device and resolve its device_id (needed for control)."""
        self._vesta._device_sn = device_sn
        if self._vesta._dry_run:
            self._vesta._device_id = "0"
            return device_sn
        did = await asyncio.to_thread(self._client.find_device_id, device_sn)
        self._vesta._device_id = did
        if not did:
            raise ConfigError(
                f"device_sn {device_sn!r} not found in this account's device list"
            )
        return device_sn

    async def bind(self, device_sn: str) -> dict:
        if self._vesta._dry_run:
            return {"code": 200, "dry_run": True}
        return await asyncio.to_thread(self._client.bind_robot, device_sn)

    async def unbind(self, device_sn: str) -> dict:
        if self._vesta._dry_run:
            return {"code": 200, "dry_run": True}
        return await asyncio.to_thread(self._client.unbind_robot, device_sn)

    # ── movement ────────────────────────────────────────────────────

    async def move(self, direction: str) -> MotionResult:
        d = direction.lower().strip().replace("-", "_")
        if d not in DIRECTIONS:
            raise CapabilityNotSupported(
                f"vesta move directions {DIRECTIONS}; got {direction!r}"
            )
        return await self._vesta._send_cmd(
            "remote_control", "on", {"type": "1", "direction": d}
        )

    async def stop(self) -> MotionResult:
        return await self._vesta._send_cmd("remote_control", "off", None)

    # ── generic action / raw command ────────────────────────────────

    async def action(
        self, cmd_type: str, status: str = "on", data: dict | None = None
    ) -> MotionResult:
        """Fire any cmd_type (friendly alias or raw wire token)."""
        return await self._vesta._send_cmd(
            self._vesta._resolve_wire(cmd_type), status, data
        )

    async def perform(self, action_id: int | str) -> MotionResult:
        """action_perform — the status field carries the action id."""
        return await self._vesta._send_cmd("action_perform", str(action_id), None)

    async def get_status(self) -> dict:
        """Raw /device/system/status/v1 payload."""
        if self._vesta._dry_run:
            return {"code": 200, "data": {"current_status": "online"}, "dry_run": True}
        if self._vesta._client is None:
            raise FFConnectionError("vesta adapter not connected")
        await self._vesta._ensure_device()
        return await asyncio.to_thread(
            self._client.system_status,
            self._vesta._device_sn, self._vesta._device_id,
        )

    # ── gesture + action shortcuts (1:1 with the cmd_type vocabulary) ──

    async def nod(self) -> MotionResult:
        return await self.action("nod")

    async def shake_head(self) -> MotionResult:
        return await self.action("shake_head")

    async def handshake(self) -> MotionResult:
        return await self.action("handshake")

    async def salute(self) -> MotionResult:
        return await self.action("salute")

    async def squat(self) -> MotionResult:
        return await self.action("squat")

    async def sway(self) -> MotionResult:
        return await self.action("sway")

    async def cheer(self) -> MotionResult:
        return await self.action("cheer")

    async def scratch_head(self) -> MotionResult:
        return await self.action("scratch_head")

    async def smirk(self) -> MotionResult:
        return await self.action("smirk")

    async def hands_on_hips(self) -> MotionResult:
        return await self.action("hands_on_hips")

    async def happy(self) -> MotionResult:
        return await self.action("happy")

    async def turn_left(self) -> MotionResult:
        return await self.action("turn_left")

    async def turn_right(self) -> MotionResult:
        return await self.action("turn_right")

    async def standup(self) -> MotionResult:
        return await self.action("standup")

    async def follow(self) -> MotionResult:
        return await self.action("follow")

    async def charge(self) -> MotionResult:
        return await self.action("charge")

    async def take_photo(self) -> MotionResult:
        return await self.action("take_photo")

    async def record_video(self) -> MotionResult:
        return await self.action("record_video")
