"""PlatformAdapter — the OEM-hiding contract.

Phase 1 surface: connect / disconnect / capabilities / diagnose / e_stop.
Phase 1.5: adds motion / state / vision / audio capability accessors (optional).
"""
from __future__ import annotations

import abc
import enum
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from ff_sdk.core.config import Config
from ff_sdk.core.identity import Identity

if TYPE_CHECKING:
    from ff_sdk.capabilities.arm import ArmCapability
    from ff_sdk.capabilities.audio import AudioCapability
    from ff_sdk.capabilities.checkin import CheckinCapability
    from ff_sdk.capabilities.display import DisplayCapability
    from ff_sdk.capabilities.motion import MotionCapability
    from ff_sdk.capabilities.navigation import NavigationCapability
    from ff_sdk.capabilities.state import StateCapability
    from ff_sdk.capabilities.vision import VisionCapability
    from ff_sdk.core.session import Session


class HealthStatus(enum.Enum):
    OK = "ok"
    WARN = "warn"
    FAIL = "fail"
    UNKNOWN = "unknown"


@dataclass(frozen=True)
class DiagnosticCheck:
    """Single check in a DiagnosticReport (e.g. 'DDS reachable',
    'runtime RPC port open', 'audio topic producing data')."""
    name: str
    status: HealthStatus
    detail: str = ""
    latency_ms: float | None = None


@dataclass(frozen=True)
class DiagnosticReport:
    platform: str
    target: str
    overall: HealthStatus
    checks: tuple[DiagnosticCheck, ...] = ()
    extra: Mapping[str, str] = field(default_factory=dict)

    def summary(self) -> str:
        marks = {HealthStatus.OK: "✓", HealthStatus.WARN: "⚠",
                 HealthStatus.FAIL: "✗", HealthStatus.UNKNOWN: "?"}
        lines = [f"[{marks[self.overall]}] {self.platform} · {self.target}"]
        for c in self.checks:
            line = f"  {marks[c.status]} {c.name}"
            if c.detail:
                line += f" — {c.detail}"
            if c.latency_ms is not None:
                line += f" ({c.latency_ms:.0f} ms)"
            lines.append(line)
        return "\n".join(lines)


class PlatformAdapter(abc.ABC):
    """Abstract contract for every supported robot platform.

    Concrete subclasses: A2Adapter, X2Adapter, D1Adapter, MujocoAdapter.

    OEM-leakage rule: concrete adapters MAY import the vendor runtime / rclpy /
    Aegis cmd modules internally, but MUST translate all return values and
    exceptions into ff_sdk types before returning to the caller.
    """

    platform_name: str = "unknown"

    def __init__(self, *, config: Config, identity: Identity) -> None:
        self.config = config
        self.identity = identity
        self._session: "Session | None" = None

    async def bind(self, *, session: "Session") -> None:
        """Called by Session during open(). Gives the adapter a chance to
        hook into the session's e_stop, logger, and audit channel."""
        self._session = session
        session.estop.register(self._on_estop)

    # --- Lifecycle ---------------------------------------------------

    @abc.abstractmethod
    async def connect(self, target: str) -> None: ...

    @abc.abstractmethod
    async def disconnect(self) -> None: ...

    # --- Capability advertisement ------------------------------------

    @abc.abstractmethod
    def capabilities(self) -> set[str]:
        """Names of Capability interfaces this platform implements
        (e.g. {"motion", "audio", "vision", "state"}).

        Phase 1 adapters return set() — capabilities are added in Phase 1.5.
        """

    # --- Diagnostics -------------------------------------------------

    @abc.abstractmethod
    def diagnose(self) -> DiagnosticReport: ...

    # --- Emergency stop ----------------------------------------------

    @abc.abstractmethod
    async def e_stop(self, *, reason: str = "manual") -> None:
        """Platform-specific hardware stop. Must be idempotent and
        respond within 500ms (PLAN.md §3)."""

    async def _on_estop(self, event: object) -> None:
        """Default: no-op. Subclasses override to cancel in-flight ops."""

    # --- Capability accessors (override in subclasses) ---------------

    @property
    def motion(self) -> "MotionCapability | None":
        """Return MotionCapability instance, or None if not supported."""
        return None

    @property
    def state(self) -> "StateCapability | None":
        return None

    @property
    def vision(self) -> "VisionCapability | None":
        return None

    @property
    def audio(self) -> "AudioCapability | None":
        return None

    @property
    def display(self) -> "DisplayCapability | None":
        return None

    @property
    def navigation(self) -> "NavigationCapability | None":
        return None

    @property
    def arm(self) -> "ArmCapability | None":
        return None

    @property
    def checkin(self) -> "CheckinCapability | None":
        return None
