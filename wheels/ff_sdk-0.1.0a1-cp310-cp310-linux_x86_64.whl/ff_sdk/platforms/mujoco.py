"""MujocoAdapter — physics-simulation platform.

A first-class platform adapter that runs the same Capability interfaces
against a Mujoco physics model. Same API path as real hardware, so Skills
tested here run identically on real robots.

Targets:
    mujoco://a2       humanoid (A2 description)
    mujoco://d1       quadruped (D1 description)

Phase 1 skeleton: connect loads the MJCF if `mujoco` is installed, otherwise
raises a typed ConnectionError (dry_run still works). e_stop halts the step
loop. Capabilities added in Phase 1.5.
"""
from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path

from ff_sdk.capabilities.motion import MotionCapability
from ff_sdk.capabilities.state import StateCapability
from ff_sdk.capabilities.types import (
    BatteryState,
    JointStates,
    MotionResult,
    Pose,
    RobotStatus,
)
from ff_sdk.core.estop import EStopEvent
from ff_sdk.core.exceptions import CapabilityNotSupported, ConfigError, ConnectionError
from ff_sdk.platforms.base import (
    DiagnosticCheck,
    DiagnosticReport,
    HealthStatus,
    PlatformAdapter,
)

log = logging.getLogger(__name__)

_KNOWN_ROBOTS = {"a2", "d1"}

# Resolve repo root: ff_sdk/python/src/ff_sdk/platforms/mujoco.py → repo root
_REPO_ROOT = Path(__file__).resolve().parents[5]
_MJCF_CANDIDATES: dict[str, tuple[Path, ...]] = {
    "a2": (
        _REPO_ROOT / "mujoco_sim" / "a2_description" / "robot_descriptions_public" / "scene.xml",
    ),
    "d1": (
        # aegis_model scene path may differ; list candidates to check at runtime
        _REPO_ROOT / "mujoco_sim" / "d1_description" / "aegis_model-main" / "scene.xml",
    ),
}


class MujocoAdapter(PlatformAdapter):
    platform_name = "mujoco"

    def __init__(self, **kwargs: object) -> None:
        super().__init__(**kwargs)  # type: ignore[arg-type]
        self._target: str = ""
        self._robot: str = "unknown"
        self._model_path: Path | None = None
        self._connected: bool = False
        self._stepping: bool = False
        self._mj_model: object | None = None
        self._mj_data: object | None = None
        self._step_task: asyncio.Task[None] | None = None
        self._motion: MujocoMotion | None = None
        self._state: MujocoState | None = None
        self._desired_twist = (0.0, 0.0, 0.0)  # linear, angular, lateral
        self._last_status: RobotStatus = RobotStatus.UNKNOWN

    async def connect(self, target: str) -> None:
        self._target = target
        self._robot = _parse_mujoco_target(target)
        self._model_path = _find_mjcf(self._robot)

        if self.config.dry_run:
            log.info("MujocoAdapter dry-run: skipping Mujoco load for %s", target)
            self._motion = MujocoMotion(self)
            self._state = MujocoState(self)
            self._connected = True
            return

        try:
            import mujoco  # type: ignore[import-not-found]
        except ImportError as e:
            raise ConnectionError(
                "mujoco package not installed. `pip install mujoco` or "
                "set FF_SDK_DRY_RUN=1."
            ) from e

        if self._model_path is None:
            raise ConnectionError(
                f"no MJCF model found for robot '{self._robot}' "
                f"(expected under mujoco_sim/{self._robot}_description/)"
            )

        try:
            self._mj_model = mujoco.MjModel.from_xml_path(str(self._model_path))
            self._mj_data = mujoco.MjData(self._mj_model)
        except Exception as e:
            raise ConnectionError(f"Mujoco load failed for {self._model_path}: {e}") from e

        self._motion = MujocoMotion(self)
        self._state = MujocoState(self)
        self._connected = True
        self._stepping = True
        self._step_task = asyncio.create_task(self._run_sim(mujoco))
        log.info("MujocoAdapter loaded: %s model=%s", target, self._model_path)

    async def _run_sim(self, mujoco_mod: object) -> None:
        """Background physics stepping. Runs at model's dt until disconnect."""
        timestep = float(self._mj_model.opt.timestep)  # type: ignore[union-attr]
        while self._stepping and self._mj_data is not None:
            try:
                mujoco_mod.mj_step(self._mj_model, self._mj_data)  # type: ignore[attr-defined]
            except Exception:
                log.exception("mj_step failed")
                break
            # Real-time-ish pacing; don't block event loop
            await asyncio.sleep(timestep)

    async def disconnect(self) -> None:
        self._stepping = False
        if self._step_task is not None:
            try:
                await asyncio.wait_for(self._step_task, timeout=1.0)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._step_task.cancel()
            self._step_task = None
        self._mj_model = None
        self._mj_data = None
        self._connected = False

    def capabilities(self) -> set[str]:
        return {"motion", "state"} if self._connected else set()

    @property
    def motion(self) -> "MujocoMotion | None":
        return self._motion

    @property
    def state(self) -> "MujocoState | None":
        return self._state

    def diagnose(self) -> DiagnosticReport:
        checks: list[DiagnosticCheck] = []

        robot = self._robot if self._robot != "unknown" else _parse_mujoco_target(self._target or "mujoco://a2", quiet=True)

        checks.append(DiagnosticCheck(
            name="robot kind",
            status=HealthStatus.OK if robot in _KNOWN_ROBOTS else HealthStatus.FAIL,
            detail=robot,
        ))

        model_path = self._model_path or _find_mjcf(robot)
        if model_path is not None:
            checks.append(DiagnosticCheck(
                name="MJCF model",
                status=HealthStatus.OK,
                detail=str(model_path),
            ))
        else:
            checks.append(DiagnosticCheck(
                name="MJCF model",
                status=HealthStatus.FAIL,
                detail=f"no scene.xml under mujoco_sim/{robot}_description/",
            ))

        try:
            import mujoco  # type: ignore[import-not-found]  # noqa: F401
            mujoco_ok = True
        except ImportError:
            mujoco_ok = False
        checks.append(DiagnosticCheck(
            name="mujoco package",
            status=HealthStatus.OK if mujoco_ok else HealthStatus.WARN,
            detail="installed" if mujoco_ok else "not installed (dry-run only)",
        ))

        checks.append(DiagnosticCheck(
            name="stepping",
            status=HealthStatus.OK if self._stepping else HealthStatus.UNKNOWN,
            detail="live" if self._stepping else ("dry-run" if self.config.dry_run else "idle"),
        ))

        overall = _overall_from(checks)
        return DiagnosticReport(
            platform=self.platform_name,
            target=self._target or "<not-connected>",
            overall=overall,
            checks=tuple(checks),
        )

    async def e_stop(self, *, reason: str = "manual") -> None:
        log.warning("Mujoco e_stop: reason=%s (target=%s)", reason, self._target)
        self._stepping = False
        # TODO (Phase 1.5): zero qvel / qfrc_applied when live physics is running

    async def _on_estop(self, event: EStopEvent) -> None:
        self._stepping = False


def _parse_mujoco_target(target: str, *, quiet: bool = False) -> str:
    """mujoco://a2 → 'a2'; mujoco://d1 → 'd1'."""
    if not target.startswith("mujoco://"):
        if quiet:
            return "unknown"
        raise ConfigError(f"mujoco target must be 'mujoco://<robot>', got {target!r}")
    robot = target[len("mujoco://"):].strip().lower() or "unknown"
    return robot


def _find_mjcf(robot: str) -> Path | None:
    for candidate in _MJCF_CANDIDATES.get(robot, ()):
        if candidate.exists():
            return candidate
    return None


def _overall_from(checks: list[DiagnosticCheck]) -> HealthStatus:
    if any(c.status is HealthStatus.FAIL for c in checks):
        return HealthStatus.FAIL
    if any(c.status is HealthStatus.WARN for c in checks):
        return HealthStatus.WARN
    if all(c.status is HealthStatus.OK for c in checks):
        return HealthStatus.OK
    return HealthStatus.UNKNOWN


# ─── Capability implementations ─────────────────────────────────────

class MujocoMotion(MotionCapability):
    """Physics-simulation motion. Commands update desired setpoints; the
    adapter's background `_run_sim` loop advances physics. No controller
    is bundled in Phase 1.5 — use a VLA policy or hand-written controller
    in Phase 3+ for realistic walking."""

    def __init__(self, adapter: "MujocoAdapter") -> None:
        super().__init__(adapter)
        self._mj: MujocoAdapter = adapter

    async def cmd_vel(self, linear: float = 0.0, angular: float = 0.0,
                      lateral: float = 0.0) -> MotionResult:
        self._mj._session_assert_operable()
        self._mj._desired_twist = (linear, angular, lateral)
        if self._mj._mj_data is not None:
            # Directly apply base velocity to free-joint qvel[:6] (if present).
            # Real MJCFs may not have a free root; treat as no-op when absent.
            try:
                if len(self._mj._mj_data.qvel) >= 6:  # type: ignore[attr-defined]
                    self._mj._mj_data.qvel[0] = linear    # type: ignore[attr-defined]
                    self._mj._mj_data.qvel[1] = lateral   # type: ignore[attr-defined]
                    self._mj._mj_data.qvel[5] = angular   # type: ignore[attr-defined]
            except Exception:
                pass
        self._mj._last_status = RobotStatus.MOVING
        log.debug("MujocoMotion.cmd_vel linear=%.2f angular=%.2f lateral=%.2f",
                  linear, angular, lateral)
        return MotionResult(True)

    async def stop(self) -> MotionResult:
        return await self.cmd_vel(0.0, 0.0, 0.0)

    async def stand(self) -> MotionResult:
        """Reset to the first keyframe (standing pose) if the model defines one."""
        self._mj._session_assert_operable()
        if self._mj._mj_data is not None and self._mj._mj_model is not None:
            try:
                import mujoco  # type: ignore[import-not-found]
                nkey = getattr(self._mj._mj_model, "nkey", 0)
                if nkey >= 1:
                    mujoco.mj_resetDataKeyframe(self._mj._mj_model,
                                                self._mj._mj_data, 0)
                else:
                    mujoco.mj_resetData(self._mj._mj_model, self._mj._mj_data)
            except Exception:
                log.exception("Mujoco stand reset failed")
                return MotionResult(False, "reset failed")
        self._mj._last_status = RobotStatus.STANDING
        return MotionResult(True, "reset to stand keyframe")

    async def damping(self) -> MotionResult:
        self._mj._session_assert_operable()
        if self._mj._mj_data is not None:
            try:
                for i in range(len(self._mj._mj_data.qvel)):  # type: ignore[attr-defined]
                    self._mj._mj_data.qvel[i] = 0.0           # type: ignore[attr-defined]
                for i in range(len(self._mj._mj_data.ctrl)):  # type: ignore[attr-defined]
                    self._mj._mj_data.ctrl[i] = 0.0           # type: ignore[attr-defined]
            except Exception:
                pass
        self._mj._desired_twist = (0.0, 0.0, 0.0)
        self._mj._last_status = RobotStatus.DAMPING
        return MotionResult(True)

    async def do_preset(self, name: str) -> MotionResult:
        key = name.lower()
        if key in ("stand", "stand_up"):
            return await self.stand()
        if key == "damping":
            return await self.damping()
        if key == "stop":
            return await self.stop()
        # In Phase 1.5 mujoco has no controller for named gestures (wave/bow/jump).
        raise CapabilityNotSupported(
            f"Mujoco has no preset '{name}' in Phase 1.5 (no policy/controller bundled)"
        )

    async def current_pose(self) -> Pose:
        if self._mj._mj_data is None:
            return Pose()
        try:
            qpos = self._mj._mj_data.qpos  # type: ignore[attr-defined]
            if len(qpos) >= 7:
                # free joint: x, y, z, qw, qx, qy, qz
                import math
                qw, qx, qy, qz = float(qpos[3]), float(qpos[4]), float(qpos[5]), float(qpos[6])
                sinr = 2 * (qw * qx + qy * qz)
                cosr = 1 - 2 * (qx * qx + qy * qy)
                roll = math.atan2(sinr, cosr)
                sinp = 2 * (qw * qy - qz * qx)
                pitch = math.asin(max(-1.0, min(1.0, sinp)))
                siny = 2 * (qw * qz + qx * qy)
                cosy = 1 - 2 * (qy * qy + qz * qz)
                yaw = math.atan2(siny, cosy)
                return Pose(x=float(qpos[0]), y=float(qpos[1]), z=float(qpos[2]),
                            roll=roll, pitch=pitch, yaw=yaw)
        except Exception:
            pass
        return Pose()


class MujocoState(StateCapability):
    """Reads state from mj_data. Battery is simulated as always-full."""

    def __init__(self, adapter: "MujocoAdapter") -> None:
        super().__init__(adapter)
        self._mj: MujocoAdapter = adapter

    async def battery(self) -> BatteryState:
        # Sim has infinite battery
        return BatteryState(percent=1.0, voltage=50.0, is_charging=False)

    async def status(self) -> RobotStatus:
        return self._mj._last_status

    async def pose(self) -> Pose:
        if self._mj._motion is None:
            return Pose()
        return await self._mj._motion.current_pose()

    async def joint_states(self) -> JointStates:
        if self._mj._mj_model is None or self._mj._mj_data is None:
            return JointStates()
        try:
            import mujoco  # type: ignore[import-not-found]
            n = self._mj._mj_model.njnt  # type: ignore[attr-defined]
            names: list[str] = []
            for i in range(n):
                nm = mujoco.mj_id2name(self._mj._mj_model, mujoco.mjtObj.mjOBJ_JOINT, i)
                names.append(nm or f"joint_{i}")
            positions = tuple(float(x) for x in self._mj._mj_data.qpos)  # type: ignore[attr-defined]
            velocities = tuple(float(x) for x in self._mj._mj_data.qvel)  # type: ignore[attr-defined]
            return JointStates(names=tuple(names), positions=positions,
                               velocities=velocities)
        except Exception:
            return JointStates()


def _mj_session_assert_operable(self: "MujocoAdapter") -> None:
    if self._session is not None:
        self._session.assert_operable()


MujocoAdapter._session_assert_operable = _mj_session_assert_operable  # type: ignore[attr-defined]
