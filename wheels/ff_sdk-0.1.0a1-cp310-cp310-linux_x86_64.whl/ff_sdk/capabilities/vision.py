"""VisionCapability — local raw camera frames only.

**In scope for Phase 1.5**: local raw frame access.
**Out of scope**: face detection / object detection / SLAM — those depend on
H200 backend services which are permanently out of ff_sdk scope (PLAN §17.1).
Downstream apps can run their own inference on raw frames.
"""
from __future__ import annotations

import abc
from collections.abc import AsyncIterator

from ff_sdk.capabilities.base import Capability
from ff_sdk.capabilities.types import CameraFrame


class VisionCapability(Capability):
    """Raw camera access. Implementations added in later Phase 1.5 ticks."""

    name = "vision"

    @abc.abstractmethod
    async def frame(self, source: str = "default") -> CameraFrame:
        """One-shot single frame grab."""

    @abc.abstractmethod
    def stream_camera(self, source: str = "default") -> AsyncIterator[CameraFrame]:
        """Async iterator yielding frames until caller stops iterating."""
