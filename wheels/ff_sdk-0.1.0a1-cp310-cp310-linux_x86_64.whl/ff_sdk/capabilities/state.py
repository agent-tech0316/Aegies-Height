"""StateCapability — platform-agnostic telemetry / state readout."""
from __future__ import annotations

import abc

from ff_sdk.capabilities.base import Capability
from ff_sdk.capabilities.types import BatteryState, JointStates, Pose, RobotStatus


class StateCapability(Capability):
    """Read-only snapshot of robot state."""

    name = "state"

    @abc.abstractmethod
    async def battery(self) -> BatteryState: ...

    @abc.abstractmethod
    async def status(self) -> RobotStatus: ...

    @abc.abstractmethod
    async def pose(self) -> Pose: ...

    async def joint_states(self) -> JointStates:
        """Optional — many platforms don't expose joint state externally.
        Default raises. Override when available."""
        from ff_sdk.core.exceptions import CapabilityNotSupported
        raise CapabilityNotSupported(
            f"joint_states not provided by {self._adapter.platform_name} state"
        )
