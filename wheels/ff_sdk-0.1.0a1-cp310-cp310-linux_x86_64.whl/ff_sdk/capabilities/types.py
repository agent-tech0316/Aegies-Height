"""Capability-layer DTOs. Immutable dataclasses and enums only.

These types are the ff_sdk public surface — they must NOT contain any OEM
library types. The vendor runtime / rclpy / mujoco types never leak into these."""
from __future__ import annotations

import enum
from dataclasses import dataclass, field


class RobotStatus(enum.Enum):
    """Generalized robot state across all platforms."""
    UNKNOWN = "unknown"
    IDLE = "idle"
    STANDING = "standing"
    MOVING = "moving"
    LYING = "lying"           # quadruped controlled lie-down (not damping)
    DAMPING = "damping"
    CHARGING = "charging"
    OTA = "ota"
    ESTOPPED = "estopped"
    FAULT = "fault"


@dataclass(frozen=True)
class Pose:
    """Robot root pose in world frame. Meters / radians. Right-handed."""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    roll: float = 0.0
    pitch: float = 0.0
    yaw: float = 0.0


@dataclass(frozen=True)
class Twist:
    """Velocity command. Quadruped ignores `lateral` if base is non-holonomic."""
    linear: float = 0.0    # m/s forward
    angular: float = 0.0   # rad/s yaw
    lateral: float = 0.0   # m/s sideways


@dataclass(frozen=True)
class BatteryState:
    percent: float                  # 0.0–1.0
    voltage: float | None = None
    is_charging: bool = False


@dataclass(frozen=True)
class JointStates:
    names: tuple[str, ...] = ()
    positions: tuple[float, ...] = ()
    velocities: tuple[float, ...] = ()
    efforts: tuple[float, ...] = ()

    def __post_init__(self) -> None:
        # lengths must match or be zero (partial observation is OK)
        ok = all(
            len(x) in (0, len(self.names))
            for x in (self.positions, self.velocities, self.efforts)
        )
        if not ok:
            raise ValueError("JointStates arrays must be same length as names")


@dataclass(frozen=True)
class CameraFrame:
    """Single camera frame. Raw bytes only; decoding is consumer's job."""
    timestamp: float                # seconds since epoch
    data: bytes                     # encoded frame (jpeg/h264/raw)
    encoding: str = "rgb8"
    width: int = 0
    height: int = 0
    source: str = ""                # e.g. "head_cam", "rgbd_0"


@dataclass(frozen=True)
class AudioChunk:
    """PCM audio chunk. 16-bit signed little-endian by convention."""
    timestamp: float
    data: bytes
    sample_rate: int = 16000
    channels: int = 1
    samples_per_channel: int = 0
    source: str = "mic"


@dataclass(frozen=True)
class MotionResult:
    """Return value from motion commands. success + optional message."""
    success: bool
    message: str = ""
    details: dict[str, str] = field(default_factory=dict)
