"""MotionCapability — platform-agnostic motion primitives."""
from __future__ import annotations

import abc
from collections.abc import AsyncIterator, Callable
from typing import Any

from ff_sdk.capabilities.base import Capability
from ff_sdk.capabilities.types import MotionResult, Pose, Twist


class MotionCapability(Capability):
    """Base motion interface. Every platform that supports motion implements this.

    Rule: when a command isn't supported on a platform (e.g. `do_preset("jump")`
    on X2 without stunts), implementations raise `CapabilityNotSupported` with
    the specific preset name — never silently no-op.
    """

    name = "motion"

    @abc.abstractmethod
    async def cmd_vel(self, linear: float = 0.0, angular: float = 0.0,
                       lateral: float = 0.0) -> MotionResult:
        """Set continuous velocity. `lateral` is honored on holonomic bases."""

    async def cmd_twist(self, twist: Twist) -> MotionResult:
        """Convenience form — forwards to cmd_vel."""
        return await self.cmd_vel(twist.linear, twist.angular, twist.lateral)

    @abc.abstractmethod
    async def stop(self) -> MotionResult:
        """Bring the robot to rest (commanded vel 0). Does NOT imply damping."""

    @abc.abstractmethod
    async def stand(self) -> MotionResult:
        """Transition to upright stance. Humanoid: stand_up; quadruped: legs stand."""

    @abc.abstractmethod
    async def damping(self) -> MotionResult:
        """Safe-halt: zero torque / actuators off. Used by e_stop paths."""

    @abc.abstractmethod
    async def do_preset(self, name: str) -> MotionResult:
        """Execute a platform-specific preset action by name.

        Platform extensions (e.g. A2 table of SetAction, D1 cmd numbers,
        X2 PresetMotion IDs) are mapped inside each adapter's implementation.
        Unknown names must raise `CapabilityNotSupported`.
        """

    async def current_pose(self) -> Pose:
        """Optional pose read. Default raises — override when available."""
        from ff_sdk.core.exceptions import CapabilityNotSupported
        raise CapabilityNotSupported(f"current_pose not provided by {self._adapter.platform_name} motion")

    # ----------------------------------------------------------------- joint streaming
    # Path A "自研运控" 切入点：连续关节角流。
    # 实现策略按平台不同：
    #   A2:  publish the runtime adapter vr_data ROS2 msg → motion_streamer → iceoryx → mc
    #        前置：SetAction RL_WHOLE_BODY_EXT_JOINT_SERVO + DisableMotionPlayer + 同机 motion_streamer 起来
    #   D1:  publish mc_sdk_msg/HighLevelCmd (走 robot-forward) 或直接 eCAL
    #   X2:  v0.9.6 暂不支持
    # 详见 services/a2_motion_research/MOTION_CONTROL_REPLACEMENT_PLAN.md

    async def joint_stream(
        self,
        q_func: Callable[[float], list[float]],
        *,
        rate_hz: float = 50.0,
        duration_s: float | None = None,
        joint_names: list[str] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Stream full-body joint angles at `rate_hz`.

        Args:
            q_func: t (sec since start) -> joint angles (rad). Length must match
                    the platform's controllable joint count (A2 = 28 incl. arms+hands;
                    D1 = 12 legs).
            rate_hz: typical 50-200 Hz; A2 motion_streamer benches ~60 Hz comfortably.
            duration_s: total run time; None = until cancelled.
            joint_names: optional override of joint order (defaults to platform canonical).

        Yields:
            telemetry dict per frame: `{"t": float, "q_cmd": list, "q_meas": list | None,
                                        "rejected": bool, "err": str | None}`

        Raises:
            CapabilityNotSupported: platform doesn't expose joint-level entry
            PreconditionFailed: SetAction mode wrong / motion_streamer not running
        """
        # Default: optional capability, not provided. Adapters with joint-level
        # control (A2 self-developed locomotion, Path A) override this. Mirrors
        # current_pose's non-abstract + default-raise pattern above.
        from ff_sdk.core.exceptions import CapabilityNotSupported

        raise CapabilityNotSupported(
            f"joint_stream not provided by {self._adapter.platform_name} motion"
        )
        yield  # unreachable — keeps this an async generator for `async for`

    # ----------------------------------------------------------------- proprioception
    async def read_joint_state(self) -> dict[str, list[float]]:
        """Read current full-body joint state.

        Returns: `{"q": [...], "qd": [...], "tau": [...] | None,
                   "joint_names": [...]}`
        - A2: 28 维（14 臂 + 12 手 + 2 颈，或细分）
        - D1: 12 维
        """
        from ff_sdk.core.exceptions import CapabilityNotSupported

        raise CapabilityNotSupported(
            f"read_joint_state not provided by {self._adapter.platform_name} motion"
        )
