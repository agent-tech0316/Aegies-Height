"""AudioCapability — local WAV playback + mic stream.

**In scope**: play a local WAV, stream mic PCM, set volume.
**Out of scope**: cloud TTS / cloud ASR — those depend on H200 backend services
(PLAN §17.1 out-of-scope). Use your own TTS/ASR endpoint and feed raw WAV/PCM.
"""
from __future__ import annotations

import abc
from collections.abc import AsyncIterator

from ff_sdk.capabilities.base import Capability
from ff_sdk.capabilities.types import AudioChunk


class AudioCapability(Capability):
    """Local audio I/O on the robot. Implementations in later Phase 1.5 ticks."""

    name = "audio"

    @abc.abstractmethod
    async def play_wav(self, wav_bytes: bytes) -> None: ...

    @abc.abstractmethod
    def stream_mic(self, source: str = "default") -> AsyncIterator[AudioChunk]: ...

    @abc.abstractmethod
    async def volume(self, level: float) -> None:
        """Set output volume 0.0–1.0."""
