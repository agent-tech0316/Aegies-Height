"""Capability layer — platform-agnostic primitives.

Per PLAN.md §5.3: all Platform adapters implement the same Capability
interfaces. Unsupported capabilities `raise CapabilityNotSupported` rather
than silent-fallback.
"""
from ff_sdk.capabilities.arm import ArmCapability, ArmJointAngles, TcpPose
from ff_sdk.capabilities.audio import AudioCapability
from ff_sdk.capabilities.base import Capability
from ff_sdk.capabilities.checkin import (
    CheckinCapability,
    EnrollResult,
    RecognitionResult,
)
from ff_sdk.capabilities.display import DisplayCapability
from ff_sdk.capabilities.motion import MotionCapability
from ff_sdk.capabilities.navigation import NavigationCapability
from ff_sdk.capabilities.state import StateCapability
from ff_sdk.capabilities.types import (
    AudioChunk,
    BatteryState,
    CameraFrame,
    JointStates,
    Pose,
    RobotStatus,
    Twist,
)
from ff_sdk.capabilities.vision import VisionCapability

__all__ = [
    "Capability",
    "MotionCapability",
    "StateCapability",
    "VisionCapability",
    "AudioCapability",
    "DisplayCapability",
    "NavigationCapability",
    "ArmCapability",
    "CheckinCapability",
    "Pose",
    "Twist",
    "BatteryState",
    "RobotStatus",
    "JointStates",
    "CameraFrame",
    "AudioChunk",
    "ArmJointAngles",
    "TcpPose",
    "EnrollResult",
    "RecognitionResult",
]
