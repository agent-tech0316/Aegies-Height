"""ff_sdk exception hierarchy.

Design rule: OEM library exceptions (the vendor runtime, rclpy, etc.) must never
leak out of the Platform layer. Platform adapters translate OEM errors into this
hierarchy.
"""


class FfSdkError(Exception):
    """Root of all ff_sdk exceptions."""


class ConfigError(FfSdkError):
    """Configuration is invalid or incomplete."""


class AuthenticationError(FfSdkError):
    """Identity / cert / token is missing, invalid, or expired."""


class ConnectionError(FfSdkError):
    """Failed to establish or maintain connection to a robot."""


class TransportError(FfSdkError):
    """Wire-level failure (socket, DDS, RPC timeout, etc.)."""


class TimeoutError(FfSdkError):
    """Operation exceeded its deadline. Distinct from asyncio.TimeoutError
    to make SDK-originated timeouts explicit in traces."""


class PlatformError(FfSdkError):
    """Platform adapter reported a failure translating an OEM error.

    The original exception is preserved as __cause__.
    """


class CapabilityNotSupported(FfSdkError):
    """The connected platform does not implement the requested capability.

    Per PLAN.md §3: never silent-fallback — raise so callers can decide.
    """


class EStopActiveError(FfSdkError):
    """Operation refused because emergency stop is currently active."""


class StateError(FfSdkError):
    """Robot is in a state that disallows this operation
    (e.g. charging, OTA, fault)."""
