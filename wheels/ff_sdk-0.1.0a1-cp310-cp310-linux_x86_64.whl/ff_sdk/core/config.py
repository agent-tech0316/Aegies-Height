"""SDK configuration. Resolved from explicit args, env vars, or files."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Config:
    """Runtime configuration.

    Environment variable overrides (prefix FF_SDK_):
        FF_SDK_CERT_DIR          default cert directory
        FF_SDK_LOG_DIR           audit / diagnostic log root
        FF_SDK_TRANSPORT_TIMEOUT default per-op timeout seconds
        FF_SDK_DISCOVERY_TIMEOUT Zenoh/LAN discovery deadline
        FF_SDK_DRY_RUN           if "1", skip real OEM calls (unit-test mode)
    """

    cert_dir: Path | None = None
    log_dir: Path = field(default_factory=lambda: Path("/var/log/ff_sdk"))
    transport_timeout: float = 5.0
    discovery_timeout: float = 3.0
    dry_run: bool = False
    extra: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_env(cls) -> Config:
        def _path(name: str) -> Path | None:
            v = os.environ.get(name)
            return Path(v) if v else None

        def _float(name: str, default: float) -> float:
            try:
                return float(os.environ.get(name, default))
            except ValueError:
                return default

        return cls(
            cert_dir=_path("FF_SDK_CERT_DIR"),
            log_dir=_path("FF_SDK_LOG_DIR") or Path("/var/log/ff_sdk"),
            transport_timeout=_float("FF_SDK_TRANSPORT_TIMEOUT", 5.0),
            discovery_timeout=_float("FF_SDK_DISCOVERY_TIMEOUT", 3.0),
            dry_run=os.environ.get("FF_SDK_DRY_RUN") == "1",
        )
