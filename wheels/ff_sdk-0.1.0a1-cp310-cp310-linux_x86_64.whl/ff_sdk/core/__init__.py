"""Core primitives: Config, Identity, Session, Exceptions, EStop."""
