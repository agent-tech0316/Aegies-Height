"""Identity — who is calling the SDK.

Three flavors:
    - Cert-based: X.509 device cert (issued via the device portal)
    - Token-based: JWT from phone_sdk login (user identity)
    - Anonymous: dev-mode, no privileges on live robots

Actual signing / TLS verification is deferred to the transport layer;
Identity only carries the material.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from ff_sdk.core.exceptions import AuthenticationError


@dataclass(frozen=True)
class Identity:
    kind: str  # "cert" | "token" | "anonymous"
    subject: str  # SN, user id, or "anonymous"
    role: str = "viewer"  # viewer | operator | admin | emergency
    cert_pem: bytes | None = None
    key_pem: bytes | None = None
    token: str | None = None
    tenant: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_cert(cls, cert_path: str | Path, key_path: str | Path | None = None,
                  role: str = "operator") -> Identity:
        cert_path = Path(cert_path)
        if not cert_path.exists():
            raise AuthenticationError(f"cert not found: {cert_path}")
        cert_pem = cert_path.read_bytes()
        key_pem: bytes | None = None
        if key_path:
            key_path = Path(key_path)
            if not key_path.exists():
                raise AuthenticationError(f"key not found: {key_path}")
            key_pem = key_path.read_bytes()
        subject = _subject_from_cert(cert_pem)
        return cls(kind="cert", subject=subject, role=role,
                   cert_pem=cert_pem, key_pem=key_pem)

    @classmethod
    def from_token(cls, token: str, role: str = "operator",
                   tenant: str | None = None) -> Identity:
        if not token:
            raise AuthenticationError("empty token")
        return cls(kind="token", subject="token-auth", role=role,
                   token=token, tenant=tenant)

    @classmethod
    def anonymous(cls) -> Identity:
        """Dev / sim identity. Must be rejected by production ff-agent."""
        return cls(kind="anonymous", subject="anonymous", role="viewer")

    def has_role(self, *allowed: str) -> bool:
        return self.role in allowed or self.role == "admin"


def _subject_from_cert(cert_pem: bytes) -> str:
    """Parse the CN out of an X.509 PEM. Falls back to a tag if parsing fails.

    Avoids a hard dependency on cryptography in Phase 1 — best-effort only.
    """
    try:
        from cryptography import x509
        cert = x509.load_pem_x509_certificate(cert_pem)
        for attr in cert.subject:
            if attr.oid._name == "commonName":
                return str(attr.value)
    except Exception:
        pass
    return "cert-subject-unknown"
