"""Emergency stop — first-class primitive.

Per PLAN.md §3: `e_stop` must respond within 500ms in any state, on any platform.

Design:
    - One EStop instance per Session
    - Multiple subsystems (transports, platform adapter, user code) can
      register callbacks; all fire on trigger
    - Trigger is non-blocking for callers; callbacks are dispatched and
      awaited in the session's event loop
    - Callbacks that raise are isolated (don't block other callbacks)
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field

log = logging.getLogger(__name__)

EStopCallback = Callable[["EStopEvent"], Awaitable[None] | None]


@dataclass(frozen=True)
class EStopEvent:
    """Details of a single e_stop trigger."""
    reason: str
    source: str  # "user" | "platform" | "transport" | "health" | ...
    trigger_time: float = field(default_factory=time.time)


class EStop:
    """Emergency stop controller.

    Thread-safety: trigger() is async-safe within a single event loop.
    Cross-thread triggers should use loop.call_soon_threadsafe(estop.trigger, ...).
    """

    def __init__(self) -> None:
        self._active = asyncio.Event()
        self._callbacks: list[EStopCallback] = []
        self._last_event: EStopEvent | None = None

    @property
    def is_active(self) -> bool:
        return self._active.is_set()

    @property
    def last_event(self) -> EStopEvent | None:
        return self._last_event

    def register(self, callback: EStopCallback) -> Callable[[], None]:
        """Register a callback; returns an unregister function."""
        self._callbacks.append(callback)

        def _unregister() -> None:
            try:
                self._callbacks.remove(callback)
            except ValueError:
                pass

        return _unregister

    async def trigger(self, reason: str = "manual", source: str = "user") -> None:
        """Fire e_stop. Idempotent — safe to call when already active."""
        if self._active.is_set():
            log.info("e_stop already active, re-trigger from %s (%s)", source, reason)
            return
        event = EStopEvent(reason=reason, source=source)
        self._last_event = event
        self._active.set()
        log.warning("E_STOP triggered: source=%s reason=%s", source, reason)
        await self._fire_callbacks(event)

    async def _fire_callbacks(self, event: EStopEvent) -> None:
        for cb in list(self._callbacks):
            try:
                result = cb(event)
                if asyncio.iscoroutine(result):
                    await result
            except Exception:
                log.exception("e_stop callback raised; continuing with others")

    def reset(self) -> None:
        """Clear e_stop state. Should only be called after operator verification."""
        self._active.clear()
        self._last_event = None
        log.info("e_stop cleared")

    async def wait_for_trigger(self) -> EStopEvent:
        """Async-wait until an e_stop fires. Returns the triggering event."""
        await self._active.wait()
        assert self._last_event is not None
        return self._last_event
