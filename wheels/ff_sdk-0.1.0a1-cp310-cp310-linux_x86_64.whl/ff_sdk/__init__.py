"""ff_sdk — FF unified robotics SDK.

Phase 1 skeleton: Transport + Platform layers only.
Authoritative design: ff_sdk/docs/PLAN.md
"""
from ff_sdk.capabilities import (
    AudioCapability,
    BatteryState,
    JointStates,
    MotionCapability,
    Pose,
    RobotStatus,
    StateCapability,
    Twist,
    VisionCapability,
)
from ff_sdk.core.config import Config
from ff_sdk.core.exceptions import (
    AuthenticationError,
    CapabilityNotSupported,
    ConfigError,
    ConnectionError,
    EStopActiveError,
    FfSdkError,
    PlatformError,
    StateError,
    TimeoutError,
    TransportError,
)
from ff_sdk.core.identity import Identity
from ff_sdk.core.session import Session, SessionState
from ff_sdk.platforms.base import DiagnosticReport, PlatformAdapter

__version__ = "0.1.0a0"

__all__ = [
    "Config",
    "Identity",
    "Session",
    "SessionState",
    "PlatformAdapter",
    "DiagnosticReport",
    # Capabilities
    "MotionCapability",
    "StateCapability",
    "VisionCapability",
    "AudioCapability",
    "Twist",
    "Pose",
    "BatteryState",
    "RobotStatus",
    "JointStates",
    # Exceptions
    "FfSdkError",
    "ConnectionError",
    "AuthenticationError",
    "CapabilityNotSupported",
    "PlatformError",
    "TransportError",
    "TimeoutError",
    "EStopActiveError",
    "StateError",
    "ConfigError",
    "connect",
]


async def connect(target: str, *, config: Config | None = None, identity: Identity | None = None) -> Session:
    """Connect to a robot by target URI.

    Target forms:
        A2-<sn>              real A2
        X2-<sn>              real X2
        D1-<sn>              real D1
        mujoco://a2          A2 in simulation
        mujoco://d1          D1 in simulation
    """
    from ff_sdk.platforms import resolve_adapter

    cfg = config or Config.from_env()
    ident = identity or Identity.anonymous()
    adapter_cls = resolve_adapter(target)
    adapter = adapter_cls(config=cfg, identity=ident)
    session = Session(target=target, adapter=adapter, config=cfg, identity=ident)
    await session.open()
    return session
